#ifndef LED_H
#define LED_H

#include "driverlib.h"
#include "PortPins.h"

// Prototypes
void InitializeLEDPortPin(void);

#endif
